import React from "react";
import "../kyc_form/user_form.css";

const UserForm = () => {
  return (
    <div className="page-container">
      <video autoPlay loop muted className="background-video">
        <source src="/assets/backgroundVid.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>

      <div className="container">
        <div className="form-container">
          <h2>Complete Your KYC</h2>
          <form>
            <label>Name:</label>
            <input type="text" placeholder="Enter your name" />
          
            <label>Phone:</label>
            <input type="tel" placeholder="Enter your phone number" />

            <label>Email:</label>
            <input type="email" placeholder="Enter your email" />

            <button type="submit">Submit</button>
          </form>
        </div>
        <div className="gif-container">
          <img src="https://cdn.dribbble.com/users/2272987/screenshots/6299780/dribbble_2.gif" alt="GIF Inspiration" className="gif-display" />
        </div>
      </div>
    </div>
  );
};

export default UserForm;
