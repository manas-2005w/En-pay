import React from "react";
import "../kyc_form/user_form.css";


const UserForm = () => {
  return (
    <div className="page-container">
      <video autoPlay loop muted className="background-video">
        <source src="/assets/backgroundVid.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>

      <div className="container">
        <div className="form-container">
          <h2>Payment with Debit Card </h2>
          <form>
            <label>Card Number</label>
            <input type="text" placeholder="Enter your card number" />
          
            <label>Holder Name</label>
            <input type="text" placeholder="Enter your holder name" />

            <label>CVV</label>
            <input type="password" placeholder="Enter your cvv" />

            <label>Expiry</label>
            <input type="text" placeholder="MM/YY" />

            <button type="submit">Submit</button>
          </form>
        </div>
        <div className="gif-container">
          <img src="https://i.pinimg.com/originals/6c/59/8b/6c598b8cb38df244eda78f8eb2f6c425.gif" alt="GIF Inspiration" className="gif-display" />
        </div>
      </div>
    </div>
  );
};

export default UserForm;
